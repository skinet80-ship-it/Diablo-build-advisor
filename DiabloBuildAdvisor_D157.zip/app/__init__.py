import os
from flask import Flask
from app.config import HOST, PORT, SECRET_KEY

from . import db


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(BASE_DIR)


def create_app():
    app = Flask(
        __name__,
        template_folder=os.path.join(BASE_DIR, "templates"),
        static_folder=os.path.join(PROJECT_DIR, "static"),
    )
    app.config["SECRET_KEY"] = SECRET_KEY
    app.config["DATABASE"] = db.DB_PATH

    db.inizializza_database()
    db.inizializza_build()
    db.inizializza_consigli_stagioni()
    db.inizializza_stagioni()
    db.inizializza_catalogo()
    db.inizializza_storico_abilita_build()

    from app.routes import bp as main_bp
    app.register_blueprint(main_bp)

    return app


app = create_app()